<?php

require_once 'dbconnection.php';

if (isset($_POST['submit'])) {
    
    $id = $_POST['id'];
    $title = $_POST['title'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $target_path="";
    $target_path=$target_path.basename($_FILES['uploadedfile']['name']);
    
    
    $sql = "UPDATE products SET title = '$title', price = '$price', category = '$category', image = '$target_path' WHERE id = '$id'";
  

    $result = $conn->query($sql);
    header("Location: index.php");
} else {

    $sql = "SELECT * FROM products WHERE id=" . $_GET['id'];
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $conn->close();
}

?>

<form method="post" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF'] ?>">
   
Title:<input type="Text" name="title" value="<?php echo $row["title"]; ?>"><br>
Price:<input type="Text" name="price" value="<?php echo $row["price"]; ?>"><br>
Category:<input type="Text" name="category" value="<?php echo $row["category"]; ?>"><br>
<input type="hidden" value="10000000" name="MAX_FILE_SIZE">
Image:<input type="file" name="uploadedfile"><br><br>
    <input type="hidden" name="id" value=<?php echo $_GET['id']; ?> >
    <input type="Submit" name="submit" value="Update">
</form>

