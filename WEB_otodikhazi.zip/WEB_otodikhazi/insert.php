<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>

</head>
<body>

<form method="post" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                
            Title:<input type="Text" name="title"><br>
            Price: <input type="Text" name="price"><br>
            Category: <input type="Text" name="category"><br>
            <input type="hidden" value="10000000" name="MAX_FILE_SIZE">
            Image:<input type="file" name="uploadedfile"><br><br>

                <input type="Submit" name="submit" value="Insert">
            </form>

        

    </body>
</html>

<?php

require_once 'dbconnection.php';

        if (isset($_POST['submit'])) {
           
            $title = $_POST['title'];
            $price = $_POST['price'];
            $type = $_POST['category'];
           
            $target_path="";
            $target_path=$target_path.basename($_FILES['uploadedfile']['name']);
          
            $sql = "INSERT INTO products (title, price, category, image) VALUES ('$title', '$price','$category', '$target_path')";
			
            if ($conn->query($sql)) {
                $conn->close();
                 echo "<script>
		        	alert('The entry was successful');
			        window.location.href='index.php';
		    	</script>";
               
            }else{
                echo "Input failed";
            }
        }      
?>