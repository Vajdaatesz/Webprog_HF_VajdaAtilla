<?php

require_once 'dbconnection.php';

$sql = "SELECT * FROM products";
$result = $conn->query($sql);

echo "<br><h2><a href='insert.php'>Új hallgató</a><h2><br>";

if ($result->num_rows > 0) {
    echo "<table border=1>";
    echo "<tr>
	        <th>ID</th>
	        <th>Title</th>
            <th>Category</th>
            <th>Image</th>
	        <th>Action</th>
	        <th>Action</th>
        </tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>". $row["id"]."</td>";
        echo "<td>". $row["title"]."</td>";  
        echo "<td>" . $row['category'] . "</td>";
        $src = $row['image'];
        echo "<td>" . "<img src= '$src' height='50px'>" . "</td>";
        echo "<td><a href=\"update.php?id=" . $row["id"] . "\">Update</a></td>";
        echo "<td><a href=\"delete.php?id=" . $row["id"] . "\">Delete</a></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>


