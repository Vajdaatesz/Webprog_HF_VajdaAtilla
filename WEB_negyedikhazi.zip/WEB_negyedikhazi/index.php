<?php

require_once "Book.php";
require_once "Library.php";
require_once "Author.php";

$library = new Library();
$author = $library->addAuthor('Thomas Mann');
$author->addBook("Casa Buddenbrook");
$author->addBook("Moartea la Venitia");
$library->addBookForAuthor('Thomas Mann', new Book("The Magic Mountain"));

$author2 = $library->addAuthor('Agatha Christie');
$author2->addBook('Morder on the Orient Express');
$author2->addBook('Death on the Nile');
$library->addBookForAuthor('Agatha Christie', new Book("Crooked House"));

try {
    $book = $library->search('Death on the Nile');
    $author = $book->getAuthor(); 
} catch (Exception $e) {
    echo $e->getMessage();
}
echo $author->getName(); 

$library->print();

?>