<?php


class Author
{
    public string $name;
    public ?array $books = [];

    public function __construct(string $name, array $books = null)
    {
        $this->name = $name;
        $this->books = $books;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName(string $name)
    {
        $this->name = $name;
    }

    public function getBooks()
    {
        return $this->books;
    }

    public function setBooks(?array $books)
    {
        $this->books = $books;
    }

    public function addBook(string $title, float $price)
    { 
        $b1=new Book($title, $price);
		    $b1->setAuthor(new Author($this->name));
        $this->books[] = $b1;
        return $b1;
    }
}
?>