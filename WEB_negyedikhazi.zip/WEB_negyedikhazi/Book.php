<?php


class Book
{
    public string $title;
    public float $price;
    public ?Author $author;

    public function __construct(string $title, float $price, Author $author = null)
    {
        $this->title = $title;
        $this->price = $price;
        $this->author = $author;
    }

    public function getTitle()
    {
        return $this->title;
    }

    public function setTitle(string $title)
    {
        $this->title = $title;
    }

    public function getPrice()
    {
        return $this->price;
    }

    public function setPrice(float $price)
    {
        $this->price = $price;
    }

    public function getAuthor()
    {
        return $this->author;
    }

    public function setAuthor(?Author $author)
    {
        $this->author = $author;
    }

    public function __toString()
    {
        return $this->title . " - " . $this->price;
    }

}

?>