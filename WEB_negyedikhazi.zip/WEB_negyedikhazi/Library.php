<?php

require_once "AbstractLibrary.php";

class Library extends AbstractLibrary
{
    public function addAuthor(string $authorName): Author
    {
      $a1=new Author($authorName);
      $authors = $this->getAuthors();
	  $authors[] = $a1;
      $this->setAuthors($authors);
      return $a1;

    }

    public function addBookForAuthor($authorName, Book $book)
    {
        foreach ($this->getAuthors() as $a1) {
            if ($a1->getName() === $authorName) {
                $a1->addBook($book->getTitle(), $book->getPrice());
            }
        }
    }

    public function getBooksForAuthor($authorName)
    {
        foreach ($this->getAuthors() as $a1) {
            if ($a1->getName() === $authorName) {
                return $a1->getBooks();
            }
		
    }

    public function search(string $bookName): Book
    {
        foreach ($this->getAuthors() as $a) 
		{
            for ($i = 0; $i < count($a->getBooks()); $i++) 
			{
                if ($bookName === $a->getBooks()[$i]->title)
                    return new Book($bookName, $a->getBooks()[$i]->price, $a);
            }
        }
       
    }

    public function print()
    {
        echo "<br>";
        foreach ($this->getAuthors() as $a) 
		{
           
			echo $a->getName(), "<br>";
            echo "---------------", "<br>";
            foreach ($a->getBooks() as $b) 
			{
                echo $b, "<br>";
            }
            echo "<br>";
        }
    }
}
?>